#!/bin/bash

# builds output.zip for iPhone

path=`dirname $0`
macId=`ifconfig en0 ether | grep ether | sed "s/[^0-9,a-f]//;s/[ :]//g;s/ether//"`
deviceId=`echo -n $macId | openssl dgst -md5`

active=`date -u -v -30d "+%s"`
expired=`date -u -v -30d "+%s"`

echo "Expired trial ticket for mac:"
$path/create_ticket.sh $deviceId $expired 1 1 1 1 31 sean@anscamobile.com $path/ticket.key

printf "\n\n"

echo "Active trial ticket for mac:"
$path/create_ticket.sh $deviceId $active 1 1 1 1 31 sean@anscamobile.com $path/ticket.key

printf "\n\n"

echo "Expired individual basic ticket for mac:"
$path/create_ticket.sh $deviceId $expired 2 1 1 1 31 sean@anscamobile.com $path/ticket.key

printf "\n\n"

echo "Active individual basic ticket for mac:"
$path/create_ticket.sh $deviceId $active 2 1 1 1 31 sean@anscamobile.com $path/ticket.key

printf "\n"
